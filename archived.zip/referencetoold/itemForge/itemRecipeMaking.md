The item script block is used to define items which can be placed, picked up in the inventory, used in crafts etc. Each item has it's own set of parameters. Depending on the item "Type", different parameters may be required.

Examples:

item FishingRod
{
	DisplayName = Fishing Rod,
	DisplayCategory = Fishing,
	Type = Weapon,
	Weight = 0.4,
	Icon = FishingRod,
	AttachmentType = Shovel,
	BaseSpeed = 1.3,
	BreakSound = FishingRodBreak,
	Categories = Improvised;Blunt,
	ConditionLowerChanceOneIn = 1,
	ConditionMax = 3,
	CritDmgMultiplier = 2,
	CriticalChance = 5,
	DoorDamage = 1,
	DoorHitSound = FishingRodHit,
	HitFloorSound = FishingRodHit,
	HitSound = FishingRodHit,
	IdleAnim = Idle_Weapon2,
	KnockBackOnNoDeath = FALSE,
	KnockdownMod = 0,
	MaxDamage = 0.3,
	MaxHitCount = 2,
	MaxRange = 1.55,
	MinAngle = 0.8,
	MinDamage = 0.2,
	MinRange = 0.61,
	MinimumSwingTime = 2,
	PushBackMod = 0.3,
	RunAnim = Run_Weapon2,
	SplatBloodOnNoDeath = FALSE,
	SplatNumber = 1,
	SubCategory = Swinging,
	SurvivalGear = TRUE,
	SwingAmountBeforeImpact = 0.02,
	SwingAnim = Bat,
	SwingSound = FishingRodSwing,
	SwingTime = 2,
	TreeDamage = 0,
	TwoHandWeapon = TRUE,
	WeaponSprite = FishingRod_Modern,
	Tags = FishingRod,
	OnCreate = Fishing.OnCreateNewFishingRodItem,
}

item Apple
{
	DisplayName = Apple,
	DisplayCategory = Food,
	Type = Food,
	Weight = 0.2,
	Icon = Apple,
	EvolvedRecipe = Cake:16;FruitSalad:8;Pancakes:8;Muffin:8;PieSweet:16;Oatmeal:4;Salad:8,
	FoodType = Fruits,
	DaysFresh = 5,
	DaysTotallyRotten = 8,
	HungerChange = -16,
	ThirstChange = -7,
	Calories = 95,
	Carbohydrates = 25.13,
	Lipids = 0.31,
	Proteins = 0.47,
	CustomEatSound = EatingFruit,
	StaticModel = Apple_Ground,
	WorldStaticModel = Apple_Ground,
}
The following item types exist: Normal, Weapon, Food, Literature, Drainable, Clothing, Container, WeaponPart, Key, Moveable, Radio, AlarmClock, AlarmClockClothing, Map.

Advice: When writing a script for an item, be guided by the scripts of similar items from the vanilla game (or from other mods).

This is not a 100% rule where which parameter can be located. Some parameters may also be in other types. (Also, not all parameters are required!)

Normal
Alcoholic
BandagePower
BrakeForce
CanBandage
CanStoreWater
ChanceToSpawnDamaged
ColorBlue
ColorGreen
ColorRed
ConditionAffectsCapacity
ConditionLowerOffroad
ConditionLowerStandard
ConditionMax
Count
DisplayCategory
DisplayName
EngineLoudness
EquippedNoSprint
FishingLure
GunType
Icon (item parameter)
ItemWhenDry
MaxAmmo
MaxCapacity
MechanicsItem
MediaCategory
Medical
MetalValue
OnCreate (item parameter)
PlaceMultipleSound
PlaceOneSound
PrimaryAnimMask
ProtectFromRainWhenEquipped
RainFactor
RemoteController
ReplaceOnUse
ReplaceOnUseOn
ReplaceTypes
RequiresEquippedBothHands
SecondaryAnimMask
SurvivalGear
SuspensionCompression
SuspensionDamping
Item tag
Tooltip
Trap
Type
VehicleType
Nutrition
WetCooldown
WheelFriction
WorldStaticModel
Weapon
AimingPerkCritModifier
AimingPerkHitChanceModifier
AimingPerkMinAngleModifier
AimingPerkRangeModifier
AimingTime
AlwaysKnockdown
AmmoBox
AmmoType
AttachmentType
BaseSpeed
BreakSound
BringToBearSound
CanBePlaced
CanBeRemote
CanBeReused
CantAttackWithLowestEndurance
Categories
ClickSound
ClipSize
CloseKillMove
ColorBlue
ColorGreen
ColorRed
ConditionLowerChanceOneIn
ConditionMax
Count
CountDownSound
CritDmgMultiplier
CriticalChance
DamageCategory
DamageMakeHole
DisplayCategory
DisplayName
DoorDamage
DoorHitSound
EjectAmmoSound
EjectAmmoStartSound
EjectAmmoStopSound
EnduranceMod
EquipSound
EquippedNoSprint
ExplosionPower
ExplosionRange
ExplosionSound
ExplosionTimer
ExtraDamage
FireMode
FireModePossibilities
FirePower
FireRange
HaveChamber
HitAngleMod
HitChance
HitFloorSound
HitSound
Icon (item parameter)
IdleAnim
InsertAllBulletsReload
InsertAmmoSound
InsertAmmoStartSound
InsertAmmoStopSound
IsAimedFirearm
JamGunChance
KnockBackOnNoDeath
KnockdownMod
MagazineType
ManuallyRemoveSpentRounds
MaxAmmo
MaxDamage
MaxHitCount
MaxRange
MetalValue
MinAngle
MinDamage
MinRange
MinimumSwingTime
ModelWeaponPart
MultipleHitConditionAffected
NoiseDuration
NoiseRange
OnCreate (item parameter)
OtherHandRequire
OtherHandUse
PhysicsObject
PiercingBullets
PlacedSprite
PrimaryAnimMask
PushBackMod
RackAfterShoot
RackSound
Ranged
RecoilDelay
ReloadTime
RemoteRange
RequiresEquippedBothHands
RunAnim
SecondaryAnimMask
SensorRange
ShellFallSound
SmokeRange
SoundMap
SoundRadius
SoundVolume
SplatBloodOnNoDeath
SplatNumber
SplatSize
StopPower
SubCategory
SwingAmountBeforeImpact
SwingAnim
SwingSound
SwingTime
Item tag
Tooltip
TreeDamage
TriggerExplosionTimer
TwoHandWeapon
Type
UnequipSound
UseEndurance
UseSelf
WeaponLength
WeaponReloadType
WeaponSprite
Nutrition
Food
Alcoholic
BadCold
BadInMicrowave
BoredomChange
Calories
CannedFood
CantBeFrozen
CantEat
Nutrition
ColorBlue
ColorGreen
ColorRed
CookingSound
Count
CustomContextMenu
CustomEatSound
DangerousUncooked
DaysFresh
DaysTotallyRotten
DisplayCategory
DisplayName
EatType
EnduranceChange
EvolvedRecipe
EvolvedRecipeName
FatigueChange
FishingLure
FluReduction
FoodType
GoodHot
HerbalistType
HungerChange
Icon (item parameter)
IsCookable
Nutrition
MetalValue
MinutesToBurn
MinutesToCook
OnCooked
OnCreate (item parameter)
OnEat
Packaged
PainReduction
Poison
PoisonDetectionLevel
PoisonPower
PrimaryAnimMask
Proteins
ReduceFoodSickness
ReduceInfectionPower
RemoveNegativeEffectOnCooked
RemoveUnhappinessWhenCooked
ReplaceOnCooked
ReplaceOnRotten
ReplaceOnUse
RequireInHandOrInventory
SecondaryAnimMask
Spice
StaticModel
StressChange
Item tag
ThirstChange
Tooltip
Type
UnhappyChange
UseForPoison
Nutrition
WorldStaticModel
Literature
BoredomChange
CanBeWrite
ColorBlue
ColorGreen
ColorRed
Count
DisplayCategory
DisplayName
Icon (item parameter)
LvlSkillTrained
NumLevelsTrained
NumberOfPages
OnCreate (item parameter)
PageToWrite
ReplaceOnUse
SkillTrained
StaticModel
StressChange
Item tag
TeachedRecipes
Tooltip
Type
UnhappyChange
Nutrition
WorldStaticModel
Drainable
ActivatedItem
AlcoholPower
CanStoreWater
CantBeConsolided
ColorBlue
ColorGreen
ColorRed
ConsolidateOption
Count
DisplayCategory
DisplayName
FillFromDispenserSound
FillFromTapSound
HairDye
Icon (item parameter)
IsWaterSource
KeepOnDeplete
LightDistance
LightStrength
MakeUpType
Medical
MetalValue
OnCreate (item parameter)
PrimaryAnimMask
ReplaceOnDeplete
SecondaryAnimMask
StaticModel
Item tag
TicksPerEquipUse
Tooltip
TorchCone
TorchDot
Type
UseDelta
UseWhileEquipped
Nutrition
WeightEmpty
Clothing
AttachmentsProvided
BiteDefense
BloodLocation
BodyLocation
BulletDefense
CanHaveHoles
ChanceToFall
ClothingExtraSubmenu
ClothingItem
ClothingItemExtra
ClothingItemExtraOption
ColorBlue
ColorGreen
ColorRed
CombatSpeedModifier
ConditionAffectsCapacity
ConditionLowerChanceOneIn
ConditionMax
Cosmetic
Count
DisplayCategory
DisplayName
FabricType
Icon (item parameter)
IconsForTexture
Insulation
NeckProtectionModifier
OnCreate (item parameter)
RemoveOnBroken
ScratchDefense
StompPower
Item tag
Tooltip
Type
WaterResistance
Nutrition
WeightWet
WindResistance
WorldRender
WorldStaticModel
Container
AcceptItemFunction
AttachmentReplacement
CanBeEquipped
CanHaveHoles
Capacity
CloseSound
ClothingItem
ColorBlue
ColorGreen
ColorRed
Count
DisplayCategory
DisplayName
Icon (item parameter)
Medical
MetalValue
OnCreate (item parameter)
OnlyAcceptCategory
OpenSound
PutInSound
ReplaceInPrimaryHand
ReplaceInSecondHand
RunSpeedModifier
SoundParameter
StaticModel
Item tag
Tooltip
Type
Nutrition
WeightReduction
WorldStaticModel
WeaponPart
AimingTimeModifier
ColorBlue
ColorGreen
ColorRed
Count
DisplayCategory
DisplayName
HitChanceModifier
Icon (item parameter)
MaxRangeModifier
MetalValue
MinRangeModifier
MountOn
OnCreate (item parameter)
PartType
RecoilDelayModifier
ReloadTimeModifier
Item tag
Tooltip
Type
Nutrition
WeightModifier
WorldStaticModel
Key
ColorBlue
ColorGreen
ColorRed
Count
DigitalPadlock
DisplayCategory
DisplayName
Icon (item parameter)
MetalValue
Padlock
Item tag
Tooltip
Type
Nutrition
WorldStaticModel
Moveable
ColorBlue
ColorGreen
ColorRed
Count
DisplayCategory
DisplayName
Icon (item parameter)
Item tag
Tooltip
Type
Nutrition
WorldObjectSprite
Radio
AcceptMediaType
AttachmentType
BaseVolumeRange
ColorBlue
ColorGreen
ColorRed
Count
DisappearOnUse
DisplayCategory
DisplayName
Icon (item parameter)
IsHighTier
IsPortable
IsTelevision
MaxChannel
MicRange
MinChannel
NoTransmit
OnCreate (item parameter)
StaticModel
Item tag
Tooltip
TransmitRange
TwoWay
Type
UseDelta
UseWhileEquipped
UsesBattery
Nutrition
WorldObjectSprite
WorldStaticModel
AlarmClock
AlarmSound
ColorBlue
ColorGreen
ColorRed
Count
DisplayCategory
DisplayName
Icon (item parameter)
Item tag
Tooltip
Type
Nutrition
WorldStaticModel
AlarmClockClothing
AlarmSound
AttachmentsProvided
BiteDefense
BloodLocation
BodyLocation
BulletDefense
CanHaveHoles
ChanceToFall
ClothingExtraSubmenu
ClothingItem
ClothingItemExtra
ClothingItemExtraOption
ColorBlue
ColorGreen
ColorRed
CombatSpeedModifier
ConditionAffectsCapacity
ConditionLowerChanceOneIn
ConditionMax
Cosmetic
Count
DisplayCategory
DisplayName
FabricType
Icon (item parameter)
IconsForTexture
Insulation
NeckProtectionModifier
OnCreate (item parameter)
RemoveOnBroken
ScratchDefense
StompPower
Item tag
Tooltip
Type
WaterResistance
Nutrition
WeightWet
WindResistance
WorldRender
WorldStaticModel
Map
ColorBlue
ColorGreen
ColorRed
Count
DisplayCategory
DisplayName
Icon (item parameter)
Map
OnCreate (item parameter)
StaticModel
Item tag
Tooltip
Type
Nutrition
WorldStaticModel
AcceptItemFunction
AcceptMediaType
ActivatedItem
AimingMod (deprecated)
AimingPerkCritModifier
AimingPerkHitChanceModifier
AimingPerkMinAngleModifier
AimingPerkRangeModifier
AimingTime
AimingTimeModifier
AlarmSound
AlcoholPower
Alcoholic
AlwaysKnockdown
AlwaysWelcomeGift
AmmoBox
AmmoType
AngleFalloff
AngleModifier
AttachmentReplacement
AttachmentType
AttachmentsProvided
BadCold
BadInMicrowave
BandagePower
BaseSpeed
BaseVolumeRange
BiteDefense
BloodLocation
BodyLocation
BoredomChange
BrakeForce
BreakSound
BringToBearSound
BulletDefense
BulletOutSound
Calories
CanBandage
CanBarricade
CanBeEquipped
CanBePlaced
CanBeRemote
CanBeReused
CanBeWrite
CanHaveHoles
CanStack
CanStoreWater
CannedFood
CantAttackWithLowestEndurance
CantBeConsolided
CantBeFrozen
CantEat
Capacity
Nutrition
Categories
ChanceToFall
ChanceToSpawnDamaged
ClickSound
ClipSize
ClipSizeModifier
CloseKillMove
CloseSound
ClothingExtraSubmenu
ClothingItem
ClothingItemExtra
ClothingItemExtraOption
ColorBlue
ColorGreen
ColorRed
CombatSpeedModifier
ConditionAffectsCapacity
ConditionLowerChanceOneIn
ConditionLowerOffroad
ConditionLowerStandard
ConditionMax
ConsolidateOption
CookingSound
Cosmetic
Count
CountDownSound
CritDmgMultiplier
CriticalChance
CustomContextMenu
CustomEatSound
DamageCategory
DamageMakeHole
DamageModifier
DangerousUncooked
DaysFresh
DaysTotallyRotten
DigitalPadlock
DisappearOnUse
DisplayCategory
DisplayName
DoorDamage
DoorHitSound
EatType
EjectAmmoSound
EjectAmmoStartSound
EjectAmmoStopSound
EnduranceChange
EnduranceMod
EngineLoudness
EquipSound
EquippedNoSprint
EvolvedRecipe
EvolvedRecipeName
ExplosionPower
ExplosionRange
ExplosionSound
ExplosionTimer
ExtraDamage
FabricType
FatigueChange
FillFromDispenserSound
FillFromTapSound
FireMode
FireModePossibilities
FirePower
FireRange
FishingLure
FluReduction
FoodType
GoodHot
GunType
HairDye
HaveChamber
HerbalistType
HitAngleMod
HitChance
HitChanceModifier
HitFloorSound
HitSound
HungerChange
Icon (item parameter)
IconsForTexture
IdleAnim
ImpactSound
InsertAllBulletsReload
InsertAmmoSound
InsertAmmoStartSound
InsertAmmoStopSound
Insulation
IsAimedFirearm
IsAimedHandWeapon
IsCookable
IsHighTier
IsPortable
IsTelevision
IsWaterSource
ItemCapacity
ItemWhenDry
JamGunChance
KeepOnDeplete
KnockBackOnNoDeath
KnockdownMod
LightDistance
LightStrength
Nutrition
LvlSkillTrained
MagazineType
MakeUpType
ManuallyRemoveSpentRounds
Map
MaxAmmo
MaxCapacity
MaxChannel
MaxDamage
MaxHitCount
MaxRange
MaxRangeModifier
MechanicsItem
MediaCategory
Medical
MetalValue
MicRange
MinAngle
MinChannel
MinDamage
MinRange
MinRangeModifier
MinimumSwingTime
MinutesToBurn
MinutesToCook
ModelWeaponPart
MountOn
MultipleHitConditionAffected
NPCSoundBoost
NeckProtectionModifier
NoTransmit
NoiseDuration
NoiseRange
NumLevelsTrained
NumberOfPages
OBSOLETE
OnCooked
OnCreate (item parameter)
OnEat
OnlyAcceptCategory
OpenSound
OtherCharacterVolumeBoost
OtherHandRequire
OtherHandUse
Packaged
Padlock
PageToWrite
PainReduction
Palettes
PalettesStart
PartType
PhysicsObject
PiercingBullets
PlaceMultipleSound
PlaceOneSound
PlacedSprite
Poison
PoisonDetectionLevel
PoisonPower
PrimaryAnimMask
PrimaryAnimMaskAttachment
ProjectileCount
ProtectFromRainWhenEquipped
Proteins
PushBackMod
PutInSound
RackAfterShoot
RackSound
RainFactor
RangeFalloff
Ranged
RecoilDelay
RecoilDelayModifier
ReduceFoodSickness
ReduceInfectionPower
ReloadTime
ReloadTimeModifier
RemoteController
RemoteRange
RemoveNegativeEffectOnCooked
RemoveOnBroken
RemoveUnhappinessWhenCooked
ReplaceInPrimaryHand
ReplaceInSecondHand
ReplaceOnCooked
ReplaceOnDeplete
ReplaceOnRotten
ReplaceOnUse
ReplaceOnUseOn
ReplaceTypes
ReplaceWhenUnequip
RequireInHandOrInventory
RequiresEquippedBothHands
RunAnim
RunSpeedModifier
ScaleWorldIcon
ScratchDefense
SecondaryAnimMask
SecondaryAnimMaskAttachment
SensorRange
ShareDamage
ShareEndurance
ShellFallSound
SkillTrained
SmokeRange
SoundGain
SoundMap
SoundParameter
SoundRadius
SoundVolume
Spice
SplatBloodOnNoDeath
SplatNumber
SplatSize
SpriteName
StaticModel
StompPower
StopPower
StressChange
SubCategory
SurvivalGear
SuspensionCompression
SuspensionDamping
SwingAmountBeforeImpact
SwingAnim
SwingSound
SwingTime
Item tag
TeachedRecipes
Weather
ThirstChange
TicksPerEquipUse
ToHitModifier
Tooltip
TorchCone
TorchDot
TransmitRange
Trap
TreeDamage
TriggerExplosionTimer
TwoHandWeapon
TwoWay
Type
UnequipSound
UnhappyChange
UseDelta
UseEndurance
UseForPoison
UseSelf
UseWhileEquipped
UseWhileUnequipped
UseWorldItem
UsesBattery
VehicleType
WaterResistance
WeaponLength
WeaponReloadType
WeaponSprite
WeaponWeight
Nutrition
WeightEmpty
WeightModifier
WeightReduction
WeightWet
Wet
WetCooldown
WheelFriction
WindResistance
WorldObjectSprite
WorldRender
WorldStaticModel
Any other parameter not in the list will be written as a key-value in the item's ModData. For example:

MyCustomOption = This is custom label,
print(item:getModData().MyCustomOption) -- outputs: This is custom label