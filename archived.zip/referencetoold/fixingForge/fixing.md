Fixing blocks are used to fix items in Project Zomboid. Example: repairing Wood Axe with different materials:

fixing Fix Wood Axe
{
    Require : WoodAxe,

    Fixer : Woodglue=2; Woodwork=2,
    Fixer : DuctTape=2,
    Fixer : Glue=2,
    Fixer : Scotchtape=4,
}
More about parameters:

Required
Item to be repaired.

Required : WoodAxe,
Fixer
This parameter specifies the material that will be used for repair and its quantity. Also, as an optional second parameter, you can specify the skill required for this type of repair. Example:

Fixer : Woodglue=2; Woodwork=2,
Fixer : DuctTape=2,
Fixer : Nails,
Important - The first parameter is the material, the second parameter (if required) is the skill.

Skill List: Axe, Blunt, SmallBlunt, LongBlade, SmallBlade, Spear, Maintenance, Aiming, Reloading, Woodwork, Cooking, Farming, Doctor, Electricity, MetalWelding, Mechanics, Tailoring, Fishing, Trapping, PlantScavenging, Fitness, Strength, Sprinting, Lightfoot , Nimble, Sneak

GlobalItem
An additional item that is needed to repair the item (to be used)

GlobalItem : DuctTape=3,
ConditionModifier
Item repair percentage modifier.

ConditionModifier : 0.3,