The vehicle script block is used to define the various aspects of a vehicle in the game. This page explains the parameters which are involved in defining a new vehicle.


Some parameters are easy to change later in game via debug tool Vehicle editor.

Vehicles use different Axis logic:
X - width.
Y - height.
Z - length.
In comparison, the game world coordinates use:

X - pointing east.
Y - pointing south.
Z - pointing up.

Vehicles are complex objects to implement due to the high amount of parameters and scripting required.
List of parameters for the vehicle block
Parameter name	Description	Example
extents	Dimensions of the physical parallelepiped that the player interacts with (X Y Z). (Vehicle dimensions that affect how close a player can approach the vehicle model). Can be configured in Vehicle Editor.	
extents = 0.7582 0.5934 1.8462,
shadowExtents	Defines the shadow dimensions under the vehicle. (X Z)	
shadowExtents = 0.7582 1.8462,
shadowOffset	Defines the shadow offset under the vehicle. (X Z)	
shadowOffset = 0.0000 0.0000,
physicsChassisShape	Dimensions of the vehicle's physical parallelepiped that interacts with the environment (X Y Z) (excluding the player)	
physicsChassisShape = 0.7582 0.5934 1.8462,
extentsOffset	Not used in game at this moment.	
extentsOffset = 1.0 1.0,
mass	Sets the vehicle weight. Affects the vehicle's physics behavior.	
mass = 650,
offRoadEfficiency	Affects the chance of parts breaking when off-road.	
offRoadEfficiency = 0.8,
centerOfMassOffset	Defines the vehicle's center of mass.	
centerOfMassOffset = 0.0000 0.3077 0.0000,
engineForce	Affects the vehicle's engine power.	
engineForce = 3600,
engineIdleSpeed	Affects the vehicle's speed in idle state.	
engineIdleSpeed = 120,
gearRatioCount	Sets the number of gears in the vehicle. (Does not affect the vehicle's maximum speed).	
gearRatioCount = 4,
textureRust	Sets the rust texture for the vehicle.	
textureRust = Vehicles/Veh_Rust,
textureMask	Sets the mask texture for the vehicle. Used to set the display of changes on certain parts of the vehicle (rust, blood, damage)	
textureMask = Vehicles/vehicle_smallcar_mask,
textureLights	Sets the texture of vehicle lights.	
textureLights = Vehicles/vehicle_smallcar_lights,
textureDamage1Overlay	Sets the texture for blood.	
textureDamage1Overlay = Vehicles/Veh_Blood_Mask,
textureDamage1Shell	Sets the texture for damage. Usually used to display light damage.	
textureDamage1Shell = Vehicles/Veh_Damage1,
textureDamage2Overlay	Sets the texture for blood. Usually the same texture as textureDamage1Overlay is used.	
textureDamage2Overlay = Vehicles/Veh_Blood_Hvy,
textureDamage2Shell	Sets the texture for damage. Usually used to display heavy damage.	
textureDamage2Shell = Vehicles/Veh_Damage2,
textureShadow	Sets the texture for the shadow under the vehicle.	
textureShadow = Vehicles/CustomShadowTexture,
steeringClamp	Modifier affecting the vehicle's turning angle.	
steeringClamp = 0.3,
suspensionStiffness	Sets suspension stiffness. (Physics param)	
suspensionStiffness = 30,
suspensionDamping	Sets suspension damping. (Physics param)	
suspensionDamping = 2.88,
suspensionCompression	Sets suspension compression. (Physics param)	
suspensionCompression = 2.83,
suspensionRestLength	Sets suspension rest length. (Physics param)	
suspensionRestLength = 0.2,
maxSuspensionTravelCm	Sets max suspension travel cm. (Physics param)	
maxSuspensionTravelCm = 10,
wheelFriction	Wheel friction modifier. (Physics param)	
wheelFriction = 1.6f,
stoppingMovementForce	Sets stopping movement force. (Physics param)	
stoppingMovementForce = 2.0f,
maxSpeed	Sets max speed. (Physics param)	
maxSpeed = 70f,
isSmallVehicle	Sets variable that used in zombie behavior logic.	
isSmallVehicle = false,
spawnOffsetY	Height at which the vehicle spawns.	
spawnOffsetY = 0.19392952,
engineLoudness	Vehicle loudness modifier.	
engineLoudness = 55,
engineQuality	Sets the engine quality. Affects the chance to start the vehicle, the chance to hotwire the vehicle. If the engine quality is less than 65 - then the weather will affect the engine start chance.	
engineQuality = 60,
mechanicType	Type of vehicle. Values:
0 - Burnt.
1 - Standard.
2 - Heavy Duty.
3 - Sport.
mechanicType = 1,
forcedColor	Sets force vehicle color values (HSV). Values: from 0.0 to 1.0. All vehicles will spawn with this color.	
forcedColor = 0.3 0.5 0.0,
engineRPMType	Sound of vehicle engine. The sound is set in the sound block from the vehicle block.	
engineRPMType = firebird,
template	Loads template. Allows loading a specific part of template code.	
template = Trunk/part/TruckBed,
template!	Loads template. Loads as if the template is part of the script code.	
template! = SmallCar,
engineRepairLevel	Required mechanics skill level for repairing the vehicle's engine.	
engineRepairLevel = 4,
playerDamageProtection	Damage modifier for the player inside the vehicle.	
playerDamageProtection = 1.2,
area	Block describes the area around the car in which the player must be in order to access the spare part (The name of area must match the name of the spare part). See area scripts for more details.	
attachment	The block describes the parameters for attachments that are used for towing and attaching trailers (trailer and trailerfront). See attachment scripts for more details.	
model	Block describes the parameters for vehicle model or part model. See model scripts for more details.	
part	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
passenger	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
physics	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
skin	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
wheel	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
lightbar	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
sound	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
Describes the area around the car in which the player must be in order to access the spare part (The name of the area must match the name of the spare part)

Example:

area Engine
{
	xywh = 0.0000 1.1374 0.7692 0.4176,
}
xywh
Coordinates of area. (X Y Width Height)

xywh = 0.5989 -0.6703 0.4286 0.4725,
The block describes the parameters for attachments that are used for towing, attaching trailers (trailer and trailerfront) or vehicle anims.

Example:

attachment trailer
{
	offset = 0.0000 0.3500 -0.7500,
	rotate = 0.0000 0.0000 0.0000,
	zoffset = -1.0000,
}
bone
Not used in game at this moment.

offset
Offset of attachment. (X Y Z)

offset = 0.0000 -0.5934 1.2582,
rotate
Rotate of attachment (X Y Z)

rotate = 0.0000 0.0000 0.0000,
canAttach
Sets attachment to which this attachment can be attached.

canAttach = trailer,
zoffset
Sets offset between attachments.

zoffset = 1.0000,
updateconstraint
DEPRECATED

Block describes the parameters for vehicle model or part model.

Example:

model
{
	file = Vehicles_SmallCar,
	scale = 1.8200,
	offset = 0.0000 0.3022 0.0000,
}
file
Name of (global) model block, that describes 3d model params.

file = Vehicles_SmallCar,
offset
Offset of vehicle model.

offset = 0.0000 0.3022 0.0000,
rotate
Rotation of vehicle model.

rotate = 0.0000 0.0000 0.0000,
scale
Scale of vehicle model.

scale = 1.8200,
The part block describes the part parameters for the vehicle part. Example:

part Headlight {
    category = lights,
    specificItem = false,
    /* ... */
}
Vector3f in script example:

offset = 0 1.2 0.4321,
key	type	brief
area	String	vehicle area
category	String	category
hasLightsRear	Boolean	adds rear lights
itemType	String	item types that can be added
mechanicRequireKey	Boolean	require key to perform mechanics actions
parent	String	parent part to sync animations
repairMechanic	Boolean	part can be fixed while installed if there is a fixing script
setAllModelsVisible	Boolean	enables all part models when part is installed
specificItem	Boolean	when true: the item type is item type + mechanicType of vehicle
wheel	String	vehicle wheel
key	type	brief
angle	Vector3f	
anim	String	
animate	Boolean	
loop	Boolean	
reverse	Boolean	
rate	Float	
offset	Vector3f	
sound	String	
For animations the model should be `static = false,`
key	type	description
capacity	Integer	container maximum capacity - capacity priority is from item first, then from part container, conditionAffectsCapacity works when item capacity is used
conditionAffectsCapacity	Boolean	capacity scales with condition
contentType	String	contentType is used for other contents than inventory items e.g. air and fuel
seat	String	vehicle seat
test	String	lua function - test is called to check if player can access container when player is near or inside vehicle
Adds door to part, has no usable values

door {}
Creates a new HashMap with lua functions.

lua {
    create = Vehicles.Create.Engine,
}
The table block is parsed into a KahluaTable. If a table exists, then it is added to; otherwise, a new table is created, and values are set, overwriting previous values.

table tableId {
    key = value,
    keyRemove = ,
    subTable {
        1 = ordered,
        2 = table,
    }
    requireInstalled = BrakeFrontLeft;SuspensionFrontLeft,
}
Adds window to part.

window { openable = true, }
key	type	brief
openable	Boolean	describes if window can be opened
Below is an example of all the different scripts involved in defining a vehicle.

Vehicle script example (source: How to create new vehicle mods)
How to create new vehicle mods - an official guide from The Indie Stone on how to create new vehicle mods.
Modding
Last modified
4 months ago
Category: