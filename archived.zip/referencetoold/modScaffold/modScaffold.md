# Project Zomboid Build 42 — Mod Structure Reference

## Overview

Every PZ mod lives in its own folder. The game detects a mod by finding a `mod.info` file inside it. Build 42 introduced a **versioned folder system** — you place your content inside a `42/` subdirectory so the game knows which build it targets. A `common/` folder holds assets shared across builds.

---

## Folder Structure

```
MyMod/
├── 42/
│   ├── mod.info
│   ├── poster.png
│   └── media/
│       ├── scripts/
│       │   ├── items/
│       │   └── recipes/
│       ├── lua/
│       │   ├── client/
│       │   ├── server/
│       │   └── shared/
│       │       └── Translate/
│       │           └── EN/
│       │               ├── Items_EN.txt
│       │               └── Recipes_EN.txt
│       ├── textures/
│       ├── models/
│       └── sound/
└── common/
```

### Version Folders

- **42/** — Build 42 content. The game checks for the highest compatible version folder. If you run game version 42.1, it loads from the `42/` folder. If a `42.21/` folder exists and you're on 42.25+, it uses that instead.
- **common/** — Resources shared across all game versions. Good for large assets like textures, models, and sounds that don't change between builds. Can be empty.

### media/ Subdirectories

| Directory | Contents |
|-----------|----------|
| `scripts/` | Text files containing item definitions, recipe definitions, vehicle scripts, and fixing blocks. Typically organized into subfolders like `items/` and `recipes/`. |
| `lua/client/` | Client-side Lua scripts. UI elements, context menus, timed actions, and anything that only runs on the player's machine. Loaded after shared scripts. |
| `lua/server/` | Server-side Lua scripts. Item spawning, farming logic, weather, and other server-only events. |
| `lua/shared/` | Lua scripts shared by both client and server. These are the **first** Lua scripts loaded. Translation files also live here under `Translate/EN/`. |
| `textures/` | PNG images. Item icons must use the `Item_` filename prefix (e.g. `Item_MyItem.png`). Also holds 3D model textures. |
| `models/` | 3D model files for weapons, clothing, vehicles, and other rendered objects. |
| `sound/` | Audio files in `.wav` or `.ogg` format. |

---

## mod.info

A plain text file that tells the game about your mod. Each line is a `key=value` pair. At minimum you need `name` and `id`.

### Fields

| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `name` | Yes | Display name shown in the mod manager. | `name=My Awesome Mod` |
| `id` | Yes | Unique identifier. Used by servers and save files to track which mods are active. Use no spaces — letters, numbers, and underscores only. | `id=MyAwesomeMod` |
| `author` | No | Your name or team name. | `author=ProjectOmen` |
| `description` | No | Short description of what the mod does. | `description=Adds new weapons and recipes.` |
| `poster` | No | Filename of the preview image shown in the mod manager. Typically `poster.png`. Can be a path like `media/poster.png`. | `poster=poster.png` |
| `icon` | No | Small icon shown next to the mod name in the mod list. | `icon=icon.png` |
| `url` | No | Link to your mod's homepage, forum thread, or GitHub. | `url=https://github.com/MyMod` |
| `modversion` | No | Your mod's version string. | `modversion=1.0.0` |
| `versionMin` | No | Minimum game version required. The mod won't load on older builds. | `versionMin=42.0.0` |
| `versionMax` | No | Maximum game version supported. | `versionMax=42.99.0` |
| `require` | No | Comma-separated list of mod IDs that must be loaded for this mod to work. | `require=OtherMod,AnotherMod` |
| `incompatible` | No | Comma-separated list of mod IDs that conflict with this mod. | `incompatible=BadMod` |
| `loadModAfter` | No | Comma-separated mod IDs that should load before this mod. Controls load order. | `loadModAfter=CoreLib` |
| `loadModBefore` | No | Comma-separated mod IDs that should load after this mod. | `loadModBefore=SomeMod` |
| `category` | No | Mod category for organization. | `category=Weapons` |
| `pack` | No | Texture pack name if the mod provides one. | `pack=MyTexturePack` |
| `tiledef` | No | Tiledef name and ID if the mod adds tile definitions. | `tiledef=MyTiles 1` |

### Example mod.info

```
name=Survivor's Toolkit
id=SurvivorsToolkit
author=ProjectOmen
description=Adds craftable tools and repair kits for the apocalypse.
poster=poster.png
modversion=1.0.0
versionMin=42.0.0
```

---

## Translation Files

Translation files live under `media/lua/shared/Translate/EN/` and follow a simple format:

**Items_EN.txt**
```
Items_EN = {
    ItemName_MyItem = "My Custom Item",
    ItemName_AnotherItem = "Another Item",
}
```

**Recipes_EN.txt**
```
Recipes_EN = {
    Recipe_MyCraftRecipe = "Craft My Item",
}
```

Each language gets its own subfolder (`EN`, `FR`, `DE`, `ES`, etc.). The game falls back to `EN` if a translation is missing.

---

## Script Files

Script files are plain text files in `media/scripts/`. They use PZ's block syntax:

```
module MyMod {
    item MyItem {
        Type = Normal,
        DisplayName = My Item,
        Weight = 1.0,
        Icon = MyItem,
    }
}
```

Recipe scripts, fixing blocks, and evolved recipes also go here. You can organize them into subfolders — the game scans `scripts/` recursively.

---

## poster.png

The preview image shown in the mod manager. Recommended size is **256x256** pixels. PNG format.

---

## Quick Checklist

1. Create your mod folder with `42/` and `common/` subdirectories
2. Write a `mod.info` with at least `name` and `id`
3. Add a `poster.png` for the mod manager
4. Put scripts in `42/media/scripts/`
5. Put Lua code in the appropriate `42/media/lua/client|server|shared/` folder
6. Put translations in `42/media/lua/shared/Translate/EN/`
7. Put textures in `42/media/textures/` (item icons need the `Item_` prefix)
8. Test by placing your mod folder in `%UserProfile%\Zomboid\mods\` or use the Steam Workshop
