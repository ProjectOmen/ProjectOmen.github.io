This page has been updated to an unstable beta version (42.13.1).
craftRecipe
Properties
Parent blocks
module
Children blocks
inputs
overlayMapper
outputs
itemMapper
ID
Any
Soft overrides
True
This article is about Build 42 crafting recipes. For crafting recipes for Build 41, see Recipe (scripts).
craftRecipes are a type of scripts used to define crafting recipes by providing a set of parameters and conditions.


Crafting recipes in Build 42 were changed to use a different formatting and system than the one used in Build 41 (Recipe).
To create a new crafting recipe, simply use the following entry in a script file:

module yourModule /* or Base */
{
    craftRecipe <RecipeID>
    {
        ...
    }
}
The <RecipeID> is a unique identifier for the recipe, and should not have spaces in it. It is used to define the name of the recipe in the translation files, in Recipes_{language}.txt. For example, if the <RecipeID> is MyRecipe, the translation file for English needs to have:

Recipes_EN = {
    Recipe_MyRecipe = "My Recipe Name",
}

The module cannot be a custom one or your mod will not work on multiplayer. In the meantime, use module Base, but you should be able to easily swap it when this gets fixed.
Present on version 42.13.0. This bug was not reported on the forums.
Different parameters can be used in the craftRecipe block to define the recipe. The following table lists the available parameters and the mandatory ones:

List of parameters for the craftRecipe block
Parameter name	Description
TagsMandatory	Specifies specific conditions which need to be respected to craft this item. At least one crafting bench tag is necessary for the craft to be recognized, such as AnySurfaceCraft.
inputsMandatory	The ingredients needed to crafting the item.
outputs	The item produced from the craft.
time	Time to craft the item. Defaults to 50.
timedAction	Specifies an animation played during the crafting process, as well as sounds and the calorie burn and body heat generation rates.
category	Specifies the category of the crafting recipe. This helps to organize and identify recipes in the crafting menu.
ToolTip	Description of the crafting which is shown in the crafting menu.
Icon	Specifies the icon associated with this crafting recipe.
itemMapper	Allows to define an item mapping for input items to create a specific output item.
OnCreate	Whenever the crafting recipe is finished, this Lua function will be called.
OnTest	Used to verify if the recipe can be crafted.
xpAward	Specifies the experience points awarded for crafting this item.
SkillRequired	Specifies the skill level required to perform this crafting action.
needToBeLearn	Should the player learn the recipe before being able to craft it.
AutoLearnAll	All the skills and their required level need to be reached to learn the recipe, not be be confused with AutoLearnAny.
AutoLearnAny	Only one of the listed skills and their required level needs to be reached to learn the recipe, not be confused with AutoLearnAll.
MetaRecipe	A meta recipe is used to link two recipes so that if the meta recipe is known then the main recipe is known.
AllowBatchCraft	Allows the recipe to be crafted in batches.
Fluids	Recipes can use fluids.
overlayMapper	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
recipeGroup	

This section may need more content.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
Available skills
You can define multiple skills and their respective experience points/levels by separating them with ;. Below is how each parameters need to be formatted:

xpAward format is skill:experience
SkillRequired format is skill:level
AutoLearnAll format is skill:level
AutoLearnAny format is skill:level
You can find the available skills in the PerkFactory.Perks class. Alternatively, you can also use modded skills defined by your mod or other mods.


This section may need more content.
Other methods to modify specific elements exist and need to be documented.
Editors are encouraged to add new material to the page while expanding upon current topics. Edit (Create account)
Below will be a list of known methods to modify specific elements of existing recipes.


The new craftRecipe from Build 42 is very limited when it comes to modifying existing recipes from the Lua compared to the previous recipe scripts from Build 41. It often requires the use of tricks to access recipe data and is often suboptimal.
Want this to change ? Push for TIS to implement proper modification methods for modders here!
Adding a new output mapper output
Below are listed methods to modify an existing craftRecipe itemMappers.

First method
This method needs the mod to define a craftRecipe with the same name as the one to add new itemMapper entries. Only the itemMapper or overlayMapper entries need to be added the craftRecipe, which will not overwrite the original craftRecipe but add new entries to it. Simply make sure that your item gets added to the inputs either by adding it manually or if the input uses item tags, that your item has the same tags.

craftRecipe DrySmallLeather
    {
        itemMapper DryLeatherSmall
        {
            Base.RaccoonLeather_Spiffo_Fur_Tan = Base.RaccoonLeather_Spiffo_Fur_Tan_Wet,
        }
        overlayMapper
        {
            Base.RaccoonLeather_Spiffo_Fur_Tan_Wet = DeerLeather,
        }
}
Second method
The second method involves the use of Lua.

Events.OnGameStart.Add(function()
    local recipe = ScriptManager.instance:getCraftRecipe("SliceHead")
    if recipe then
        local outputs = recipe:getOutputs()
        for i=0, outputs:size()-1 do
            local out = outputs:get(i)
            local mapper = out:getOutputMapper()
            if mapper then
                local list = ArrayList.new()
                list:add("HorseMod.Horse_Head")
                mapper:addOutputEntree("HorseMod.Horse_Skull", list)
                mapper:OnPostWorldDictionaryInit(recipe:getName())
            end
        end
    end
end)
Adding new inputs
Below is an example of how you can add new items to the inputs of an existing craftRecipe using Lua. The hardest part of adding new items to inputs is identifying the inputs themselves, which is done with a testFunction in the example below. The reason it is so complicated to add to inputs is that it involves directly accessing the cached item script inputs stored in a Java field called loadedItems, thus requiring access via reflection, and directly adding your item entries in there.

In the example provided, the recipe also depends on itemMappers, so you need to make sure to patch using the method described in #Adding a new output mapper output.

 Full snipet for adding new inputs to an existing craftRecipe
Below are a few examples of vanilla crafting recipes you can do:

Source: ProjectZomboid\media\scripts\recipes\recipes_carpentry.txt

Retrieved: Build 42.8.1

craftRecipe SawLogs
{
    timedAction = SawLogs,
    Time = 230,
    Tags = InHandCraft;CanBeDoneFromFloor,
    category = Carpentry,
    xpAward = Woodwork:5,
    inputs
    {
        item 1 [Base.Log] flags[Prop2],
        item 1 tags[Saw] mode:keep flags[MayDegradeLight;Prop1],
    }
    outputs
    {
        item 3 Base.Plank,
    }
}
Source: ProjectZomboid\media\scripts\recipes\recipes_lightsources.txt

Retrieved: Build 42.8.1

craftRecipe RefillHurricaneLantern
{
    timedAction = Making,
    Time = 50,
    OnCreate = Recipe.OnCreate.RefillHurricaneLantern,
    /* OnTest = Recipe.OnTest.RefillHurricaneLantern, */
    Tags = InHandCraft;CanBeDoneInDark,
    category = Miscellaneous, /*category = Survival,*/
    inputs
    {
        item 1 [Base.Lantern_Hurricane;Base.Lantern_Hurricane_Copper;Base.Lantern_Hurricane_Forged;Base.Lantern_Hurricane_Gold;Base.Lantern_Hurricane_Silver] mode:destroy flags[NotFull;AllowFavorite;InheritFavorite;ItemCount] mappers[LampMapper],
        item 1 [*],
        -fluid 1.0 [Petrol],
    }
    outputs
    {
        item 1 mapper:LampMapper,
    }
    itemMapper LampMapper
    {
        Base.Lantern_Hurricane = Base.Lantern_Hurricane,
        Base.Lantern_Hurricane_Copper = Base.Lantern_Hurricane_Copper,
        Base.Lantern_Hurricane_Forged = Base.Lantern_Hurricane_Forged,
        Base.Lantern_Hurricane_Gold = Base.Lantern_Hurricane_Gold,
        Base.Lantern_Hurricane_Silver = Base.Lantern_Hurricane_Silver,

        default = Base.Lantern_Hurricane,
    }
}
Source: ProjectZomboid\media\scripts\recipes\recipes_bone.txt

Retrieved: Build 42.8.1

craftRecipe CarveWhistle
{
    time = 200,
    tags = AnySurfaceCraft;Survivalist,
    category = Carving,
    xpAward = Carving:60,
    SkillRequired = Carving:6,
    needTobeLearn = true,
    AutoLearnAny = Carving:8,
    timedAction = SharpenStake,
    inputs
    {
        item 1 tags[DrillWood;DrillMetal;DrillWoodPoor] mode:keep flags[MayDegradeLight],
        item 1 tags[SharpKnife] mode:keep flags[MayDegradeLight],
        item 1 [Base.SmallAnimalBone] flags[Prop2;AllowDestroyedItem],
    }
    outputs
    {
        item 1 Base.Whistle_Bone,
    }
}